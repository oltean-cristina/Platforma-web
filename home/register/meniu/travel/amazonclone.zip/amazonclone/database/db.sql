
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";




--

--
CREATE DATABASE IF NOT EXISTS `amaclone` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `amaclone`;

-- --------------------------------------------------------

--
-- Structura tabelului brands
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- datele din tabelul brand
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'All Inclusive'),
(2, 'Circuite'),
(3, 'Family'),
(4, 'Honey Moon'),
(5, 'Luxary'),
(6, 'Safari'),
(7, 'Scuba diving'),
(8, 'Wellness & SPA');


-- --------------------------------------------------------

--
-- structura tabelului cart
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_image` varchar(300) NOT NULL,
  `qty` int(100) NOT NULL,
  `price` int(100) NOT NULL,
  `total_amount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- date din tabelul cart
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `product_title`, `product_image`, `qty`, `price`, `total_amount`) VALUES
(79, 11, '0.0.0.0', 2, 'Baby Shirt', 'babyshirt.JPG', 1, 500, 500),
(80, 2, '0.0.0.0', 2, 'iPhone 5s', 'iphonemobile.JPG', 1, 25000, 25000);

-- --------------------------------------------------------

--
-- structura tabel categorii
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- date tabel categorii
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Europe'),
(2, 'Asia'),
(3, 'Australia & Pacific'),
(4, 'North & South America'),
(5, 'Caraibe'),
(6, 'Africa');

-- --------------------------------------------------------

--
-- Tabelul `customer_order`
--

CREATE TABLE `customer_order` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_price` int(100) NOT NULL,
  `p_qty` int(100) NOT NULL,
  `p_status` varchar(100) NOT NULL,
  `tr_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Date tabel `customer_order`
--

INSERT INTO `customer_order` (`id`, `uid`, `pid`, `p_name`, `p_price`, `p_qty`, `p_status`, `tr_id`) VALUES
(30, 2, 6, 'LG Aqua 2', 15000, 1, 'CONFIRMED', '15179'),
(31, 2, 15, 'Football Shoes', 2500, 1, 'CONFIRMED', '15179'),
(32, 2, 16, 'Football', 600, 1, 'CONFIRMED', '15179');

-- --------------------------------------------------------

--
-- Tabel `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` varchar(100) NOT NULL,
  `product_brand` varchar(100) NOT NULL,
  `product_title` varchar(50) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Date tabel `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, '1', '1', 'Aloe Boutique & Suites Creta 5*, Grecia', 675, 'Cazare 7 nopti cu mic dejun inclus', 'grecia1.JPG', 'Summer is here!'),
(2, '3', '5', 'Holiday Inn Resort Montego Bay 4*, Jamaica', 1225, '8 zile în paradis ', 'jamaica1.JPG', 'Get it now!'),
(3, '4', '7', 'Paradisus Princesa Del Mar 5*, Cuba', 1360, 'All-inclusive + scuba diving lessons', 'cuba1.jpg', 'Adventure underwater!'),
(4, '6', '8', 'Ocean Paradise 4*, Zanzibar', 1375, 'Get the ultimate relaxation center!', 'zanzibar1.JPG', 'Relaxing time!'),
(5, '2', '8', 'Diamond Cliff Resort & Spa 5*, Thailanda', 975, '7 days of peace and relaxation', 'thailanda1.JPG', 'Focus on your inner self!'),
(6, '6', '6', 'Safari Kenya', 2390, 'Get to interact with the wild animals', 'kenya1.JPG', 'Get the ultimate safari experience!'),
(7, '2', '4', 'Discovery Kartika Plaza 4*, Bali', 930, 'Enjoy romantic dinners at the sunset', 'bali1.JPG', 'Love is in the air!'),
(8, '3', '1', 'Acta City47 4*', 385, 'Visit the beautiful city of Barcelona', 'barcelona1.JPG', 'Discover new places!'),
(9, '1', '4', 'Bradford Elysees', 365, 'Visit the beautiful city of Paris', 'paris1.JPG', 'Discover new places!'),
(10, '2', '4', 'Royal Palms Beach 5*, Sri Lanka', 1030, '7 days in Paradise', 'srilanka1.JPG', 'Experience this magical island!'),
(11, '2', '2', 'Circuit Japonia - noiembrie 2021', 3690, 'Experience the beautiful city of Seoul', 'japonia1.JPG', 'Get to know the culture!'),
(12, '6', '2', 'Hotel Grand Nile Tower', 360, '5* Hotel in the heart of Cairo', 'egipt1.JPG', 'You can ride a camel!'),
(13, '3', '8', 'Sofitel Bora Bora Private Island 5*', 4450, 'Experience our scuba diving lessons!', 'bora1.JPG', 'Discover the wildlife of this island! '),
(14, '3', '1', 'Porto Bay Rio International 4*', 1245, 'You will have a spectacular view of the Copacabana sea', 'brazilia1.JPG', 'Get to know the locals!');

-- --------------------------------------------------------

--
-- structura tabel `received_payment`
--

CREATE TABLE `received_payment` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `amt` int(100) NOT NULL,
  `tr_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- structura tabel `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- date tabel `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(6, 'Cristina', 'Oltean', 'oltean.cristinagabriela@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b', '0741750150', 'Str Liviu Rebreanu', 'Str Liviu Rebreanu');


--
-- Indexes dumped tables
--

--
-- Indexes table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes  table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes  table `received_payment`
--
ALTER TABLE `received_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT  dumped tables
--

--
-- AUTO_INCREMENT  table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT  table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT  table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT  table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT  table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT  table `received_payment`
--
ALTER TABLE `received_payment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT  table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
